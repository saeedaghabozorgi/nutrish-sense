import json
import asyncio
import os
import vertexai
from google.adk.agents import LlmAgent
from google.adk.tools import AgentTool
from google.adk.runners import InMemoryRunner
from google.genai.types import Part, UserContent, GenerateContentConfig

# Setup
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
vertexai.init(project="saeed-demo-proj", location="us-central1")

from dietary_agent.sub_agents.vision_agent import vision_agent
from dietary_agent.sub_agents.chronic_agent import chronic_agent

class DietaryCoordinatorAgent:
    def __init__(self):
        # Define Schema once
        self.response_schema = {
            "type": "OBJECT",
            "properties": {
                "food_name": {"type": "STRING"},
                "overall_color": {"type": "STRING"},
                "assessments": {
                    "type": "ARRAY",
                    "items": {
                        "type": "OBJECT",
                        "properties": {
                            "condition": {"type": "STRING"},
                            "color": {"type": "STRING"},
                            "reasoning": {"type": "STRING"}
                        },
                        "required": ["condition", "color", "reasoning"]
                    }
                },
                "alternatives": {"type": "STRING"}
            },
            "required": ["food_name", "overall_color", "assessments", "alternatives"]
        }

        self.chief_agent = LlmAgent(
            name="chief_agent",
            model="gemini-3-flash-preview",
            instruction="""
            Analyze the food image provided.
            1. Use the vision_agent tool.
            2. Use the chronic_agent tool for each condition listed in the patient context.
            3. Act as the Chief Dietician. Review the individual disease assessments and determine the SAFEST OVERALL color across ALL conditions (Green, Yellow, or Red). 
            4. Compile the final assessment into the required JSON schema format.
            You MUST output only the raw JSON. Do not write any other conversational text.
            """,
            tools=[AgentTool(agent=a) for a in [vision_agent, chronic_agent]],
            output_schema=self.response_schema
        )

    async def query(self, image_uri: str, diseases: str, **kwargs) -> dict:
        """Streamlined entry point."""
        # Cleanly merge kwargs into context
        context = "\n".join([f"{k.replace('_', ' ').title()}: {v}" for k, v in kwargs.items() if v])
        prompt = f"Analyze this image for a patient with: {diseases}\n{context}"

        user_input = UserContent(parts=[
            Part.from_uri(file_uri=image_uri, mime_type="image/jpeg"),
            Part.from_text(text=prompt)
        ])

        runner = InMemoryRunner(agent=self.chief_agent)
        
        session = await runner.session_service.create_session(
            app_name=runner.app_name, user_id="app_user"
        )
        
        try:
            # Short-circuit: Just get the last event content
            result = ""
            async for event in runner.run_async(
                user_id=session.user_id,
                session_id=session.id,
                new_message=user_input
            ):
                if event.content and event.content.parts:
                    result = event.content.parts[0].text
            
            trimmed = result.strip()
            if trimmed.startswith('```json'): trimmed = trimmed[7:]
            if trimmed.endswith('```'): trimmed = trimmed[:-3]
            
            return json.loads(trimmed.strip())
        except Exception as e:
            return {"error": f"Pipeline failed: {str(e)}", "overall_color": "Red"}

    def set_up(self): pass