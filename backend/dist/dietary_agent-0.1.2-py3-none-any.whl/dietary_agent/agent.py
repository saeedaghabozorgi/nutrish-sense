import json
import asyncio
import os
import vertexai
from google.adk.agents import LlmAgent
from google.adk.tools import AgentTool
from google.adk.runners import InMemoryRunner
from google.genai.types import Part, UserContent, GenerateContentConfig

# Setup
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
vertexai.init(project="saeed-demo-proj", location="us-central1")

from dietary_agent.sub_agents.vision_agent import vision_agent
from dietary_agent.sub_agents.chronic_agent import chronic_agent
from dietary_agent.sub_agents.logic_engine import logic_engine
from pydantic import BaseModel, Field

class AssessmentModel(BaseModel):
    condition: str = Field(description="The medical condition evaluated")
    color: str = Field(description="The assigned color: Green, Yellow, or Red")
    reasoning: str = Field(description="Clinical reasoning for the assessment")

class FinalAssessment(BaseModel):
    food_name: str = Field(description="Short name of the food")
    overall_color: str = Field(description="Safest overall color (Green, Yellow, or Red)")
    assessments: list[AssessmentModel] = Field(description="List of individual condition assessments")
    alternatives: str = Field(description="Healthy alternatives text")

class DietaryCoordinatorAgent:
    def __init__(self):
        # Configure logic engine to use exact Pydantic output schema
        logic_engine.output_schema = FinalAssessment

        self.chief_agent = LlmAgent(
            name="chief_agent",
            model="gemini-3-flash-preview",
            instruction="""
            Analyze the food image provided.
            1. Use the vision_agent tool.
            2. Use the chronic_agent tool for each condition listed in the patient context.
            3. Use the logic_engine tool to format the final JSON output.
            You must output ONLY what the logic_engine returns. Do not write any other conversational text.
            """,
            tools=[AgentTool(agent=a) for a in [vision_agent, chronic_agent, logic_engine]]
        )

    async def query(self, image_uri: str, diseases: str, **kwargs) -> dict:
        """Streamlined entry point."""
        # Cleanly merge kwargs into context
        context = "\n".join([f"{k.replace('_', ' ').title()}: {v}" for k, v in kwargs.items() if v])
        prompt = f"Analyze this image for a patient with: {diseases}\n{context}"

        user_input = UserContent(parts=[
            Part.from_uri(file_uri=image_uri, mime_type="image/jpeg"),
            Part.from_text(text=prompt)
        ])

        runner = InMemoryRunner(agent=self.chief_agent)
        
        session = await runner.session_service.create_session(
            app_name=runner.app_name, user_id="app_user"
        )
        
        try:
            # Short-circuit: Just get the last event content
            result = ""
            async for event in runner.run_async(
                user_id=session.user_id,
                session_id=session.id,
                new_message=user_input
            ):
                if event.content and event.content.parts:
                    result = event.content.parts[0].text
            
            trimmed = result.strip()
            if trimmed.startswith('```json'): trimmed = trimmed[7:]
            if trimmed.endswith('```'): trimmed = trimmed[:-3]
            
            return json.loads(trimmed.strip())
        except Exception as e:
            return {"error": f"Pipeline failed: {str(e)}", "overall_color": "Red"}

    def set_up(self): pass