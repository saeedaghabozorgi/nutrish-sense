import os
import vertexai
from google.adk.agents import LlmAgent
from google.adk.runners import InMemoryRunner
from google.genai.types import Part, UserContent

# Setup
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
vertexai.init(project="saeed-demo-proj", location="us-central1")

class DietaryCoordinatorAgent:
    def __init__(self):
        self.chief_agent = LlmAgent(
            name="chief_agent",
            model="gemini-3-flash-preview",
            instruction="""
            Act as a medical dietician. 
            Analyze the food image provided and the patient's context (diseases, lab results, medications, allergies).
            Provide a detailed assessment of how this food affects the patient's conditions, and suggest healthy alternatives.
            Please format your response clearly. You should provide the assesment per user's desease, and overall assesment. Feel free to use lists or paragraphs.
            You should provide the response in JSON format with the following structure:
            {
                "food_name": "Name of the food",
                "food_category": "Category of the food",
                "overall_color": "Color associated to degree of the food being healthy or unhealthy considering users diseases. Green for healthy, Yellow for moderate, Red for unhealthy.",
                "overall_rating": "Overall rating of the food",
                "overall_assessment": "Overall assessment of the food",
                "disease_assessments": {
                    "disease_name": "Assessment of the food for the disease",
                    "disease_name": "Assessment of the food for the disease"
                },
                "healthy_alternatives": [
                    "Healthy alternative 1",
                    "Healthy alternative 2"
                ]
            }
            """
        )

    def query(self, image_uri: str, diseases: str, **kwargs) -> dict:
        """Synchronous entry point."""
        context = "\n".join([f"{k.replace('_', ' ').title()}: {v}" for k, v in kwargs.items() if v])
        prompt = f"Analyze this image for a patient with: {diseases}\n{context}"

        user_input = UserContent(parts=[
            Part.from_uri(file_uri=image_uri, mime_type="image/jpeg"),
            Part.from_text(text=prompt)
        ])

        runner = InMemoryRunner(agent=self.chief_agent)
        
        import asyncio
        import uuid
        unique_user_id = f"user_{str(uuid.uuid4())}"
        
        # 1. Use the synchronous create_session (remove 'await' by using asyncio.run)
        session = asyncio.run(runner.session_service.create_session(
            app_name=runner.app_name, user_id=unique_user_id
        ))
        
        try:
            # 2. Use runner.run instead of run_async
            # This returns a generator in the ADK
            result = ""
            for event in runner.run(
                user_id=session.user_id,
                session_id=session.id,
                new_message=user_input
            ):
                if getattr(event, 'content', None) and event.content.parts:
                    result += event.content.parts[0].text
            
            # Formatting logic remains the same
            cleaned_result = result.strip()
            if cleaned_result.startswith('```json'):
                cleaned_result = cleaned_result[7:]
            if cleaned_result.endswith('```'):
                cleaned_result = cleaned_result[:-3]
                
            return {"raw_text": cleaned_result.strip()}
        except Exception as e:
            return {"error": f"Sync Pipeline failed: {str(e)}"}

    def set_up(self): pass