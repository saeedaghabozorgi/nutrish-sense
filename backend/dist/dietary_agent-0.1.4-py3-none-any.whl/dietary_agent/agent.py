import os
import vertexai
from google.adk.agents import LlmAgent
from google.adk.runners import InMemoryRunner
from google.genai.types import Part, UserContent

# Setup
os.environ["GOOGLE_GENAI_USE_VERTEXAI"] = "true"
vertexai.init(project="saeed-demo-proj", location="us-central1")

class DietaryCoordinatorAgent:
    def __init__(self):
        self.chief_agent = LlmAgent(
            name="chief_agent",
            model="gemini-3-flash-preview",
            instruction="""
            Act as a medical dietician. 
            Analyze the food image provided and the patient's context (diseases, lab results, medications, allergies).
            Provide a detailed assessment of how this food affects the patient's conditions, and suggest healthy alternatives.
            Please format your response clearly. Feel free to use lists or paragraphs.
            """
        )

    async def query(self, image_uri: str, diseases: str, **kwargs) -> dict:
        """Streamlined entry point."""
        context = "\n".join([f"{k.replace('_', ' ').title()}: {v}" for k, v in kwargs.items() if v])
        prompt = f"Analyze this image for a patient with: {diseases}\n{context}"

        user_input = UserContent(parts=[
            Part.from_uri(file_uri=image_uri, mime_type="image/jpeg"),
            Part.from_text(text=prompt)
        ])

        runner = InMemoryRunner(agent=self.chief_agent)
        
        # Generate a completely unique user ID for every single request.
        # This completely bypasses the ADK's internal SQLite conversation history cache,
        # preventing it from loading the old stale JSON format from previous runs.
        import uuid
        unique_user_id = f"user_{str(uuid.uuid4())}"
        
        session = await runner.session_service.create_session(
            app_name=runner.app_name, user_id=unique_user_id
        )
        
        try:
            result = ""
            async for event in runner.run_async(
                user_id=session.user_id,
                session_id=session.id,
                new_message=user_input
            ):
                if getattr(event, 'content', None) and event.content.parts:
                    result = event.content.parts[0].text
            
            # Clean up potential markdown formatting from the simple text agent
            cleaned_result = result.strip()
            if cleaned_result.startswith('```json'):
                cleaned_result = cleaned_result[7:]
            if cleaned_result.endswith('```'):
                cleaned_result = cleaned_result[:-3]
                
            return {"raw_text": cleaned_result.strip()}
        except Exception as e:
            return {"error": f"Pipeline failed: {str(e)}"}

    def set_up(self): pass